# Script-Controlled ACL Demo

Open `index.html` in Chrome, Edge, Firefox, or another modern browser.

Features:
- User and record selectors
- Script-controlled ACL evaluation
- Access Granted / Denied result
- Condition analysis
- Session statistics
- Recent access logs
- Responsive modern UI

This is a front-end demonstration only. The ACL logic runs in the browser and is not suitable as a production security mechanism.
